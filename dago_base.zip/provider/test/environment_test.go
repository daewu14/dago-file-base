package test

import (
	"testing"
)

func TestLoadEnv(t *testing.T) {
	provider.LoadEnv()
}
