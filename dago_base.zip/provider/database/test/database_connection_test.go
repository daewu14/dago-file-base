package test

import (
	"testing"
)

func TestDatabaseConnection(t *testing.T) {
	provider.LoadEnv()
	defer database.Close()
	db := database.Open()
	println("database is not nil", db.Main() != nil)
}
