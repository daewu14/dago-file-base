package database

// MYSQL string constanta of supported connection
const MYSQL = "mysql"

// List of supported database connections
var supportedConnections []string = []string{
	MYSQL,
}
