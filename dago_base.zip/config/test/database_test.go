package test

import (
	"testing"
)

func TestDatabase(t *testing.T) {
	provider.LoadEnv()
	config.Database()
}
