package main

func main() {
	new(provider.App).Start()
}
